---
name: Feature request
about: Help make Logger++ awesome!
title: ''
labels: enhancement
assignees: CoreyD97

---

**Feature description:**
I want...

**Scenario example:**
This would... (make it easier to write filters, help export logs to other tools, etc)
