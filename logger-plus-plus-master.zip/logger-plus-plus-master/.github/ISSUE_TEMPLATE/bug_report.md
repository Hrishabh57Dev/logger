---
name: Bug report
about: Help improve Logger++
title: ''
labels: bug
assignees: CoreyD97

---

**Description:**

**Steps To Reproduce:**


**Expected behavior:**


**Screenshots:**

**Version:**
