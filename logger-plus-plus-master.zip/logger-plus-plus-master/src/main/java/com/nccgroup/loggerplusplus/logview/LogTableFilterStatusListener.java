package com.nccgroup.loggerplusplus.logview;

public interface LogTableFilterStatusListener {
    void onFilteringStart();
    void onFilteringFinish();
}
