package com.nccgroup.loggerplusplus.util.userinterface.renderer;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;

/**
 * Created by corey on 07/09/17.
 */
public class LeftTableCellRenderer extends DefaultTableCellRenderer {
    public LeftTableCellRenderer() {
        setHorizontalAlignment(SwingConstants.LEFT);
    }
}
