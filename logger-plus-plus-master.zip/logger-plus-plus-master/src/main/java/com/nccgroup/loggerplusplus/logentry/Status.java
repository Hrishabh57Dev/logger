package com.nccgroup.loggerplusplus.logentry;

public enum Status {
    UNPROCESSED, AWAITING_RESPONSE, PROCESSED, IGNORED
}
